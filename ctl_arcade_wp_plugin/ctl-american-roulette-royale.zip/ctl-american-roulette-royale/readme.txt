=== CTL American Roulette Royale ===
Tags: bet, casino, casino game, gambling, game, instant win, mobile, poker, roulette, roulette game, sweepstakes, table, texas, wheel
Requires at least: 4.3
Tested up to: 4.3

Add American Roulette Royale to CTL Arcade plugin

== Description ==
Add American Roulette Royale to CTL Arcade plugin


	